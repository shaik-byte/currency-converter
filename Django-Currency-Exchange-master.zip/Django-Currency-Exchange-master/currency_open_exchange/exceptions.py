class RateBackendError(Exception):
    """
    Base exceptions raised by RateBackend implementations
    """
